﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void txtTexto_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permitindo inserir apenas letras, espaço e teclar backspace
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != 08 && e.KeyChar != 32)
            {
                e.Handled = true;
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (txtTexto.Text == "" || txtTexto.Text.Length > 50)
            {
                MessageBox.Show("Campo vazio ou limite de 50 caracteres excedido. Preencha corretamente!");
            }
            else
            {
                txtTexto.Text = txtTexto.Text.Replace(" ", "");
                txtTexto.Text = txtTexto.Text.ToUpper();
                string s = txtTexto.Text;
                char[] arr = s.ToCharArray();//jogo a string para um array
                Array.Reverse(arr);//invertendo o array
                s = "";
                foreach (char c in arr)
                {
                    s = s + c.ToString();
                }
                string palavraInvertida = s;
                if (palavraInvertida == txtTexto.Text)
                {
                    MessageBox.Show("É um palíndromo!");
                }
                else
                {
                    MessageBox.Show("Não é um palíndromo!");
                }
            }
            
           
        }
    }
}
