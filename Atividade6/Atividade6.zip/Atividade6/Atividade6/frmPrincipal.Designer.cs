﻿namespace Atividade6
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrincipal));
            this.gbAtiv1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAtiv1 = new System.Windows.Forms.Button();
            this.gbAtiv3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAtiv3 = new System.Windows.Forms.Button();
            this.gbAtiv2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAtiv2 = new System.Windows.Forms.Button();
            this.gbAtiv4 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnAtiv4 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.gbAtiv1.SuspendLayout();
            this.gbAtiv3.SuspendLayout();
            this.gbAtiv2.SuspendLayout();
            this.gbAtiv4.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbAtiv1
            // 
            this.gbAtiv1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbAtiv1.BackColor = System.Drawing.SystemColors.Menu;
            this.gbAtiv1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gbAtiv1.BackgroundImage")));
            this.gbAtiv1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gbAtiv1.Controls.Add(this.label2);
            this.gbAtiv1.Controls.Add(this.label1);
            this.gbAtiv1.Controls.Add(this.btnAtiv1);
            this.gbAtiv1.Location = new System.Drawing.Point(12, 91);
            this.gbAtiv1.Name = "gbAtiv1";
            this.gbAtiv1.Size = new System.Drawing.Size(249, 101);
            this.gbAtiv1.TabIndex = 0;
            this.gbAtiv1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(88, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 39);
            this.label2.TabIndex = 2;
            this.label2.Text = "Programa que lê uma frase e \r\nmostra o número de espaços \r\nem branco que existem " +
    "na....";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(88, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Exercício 1";
            // 
            // btnAtiv1
            // 
            this.btnAtiv1.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnAtiv1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtiv1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnAtiv1.Location = new System.Drawing.Point(6, 19);
            this.btnAtiv1.Name = "btnAtiv1";
            this.btnAtiv1.Size = new System.Drawing.Size(76, 76);
            this.btnAtiv1.TabIndex = 0;
            this.btnAtiv1.Text = "Ir";
            this.btnAtiv1.UseVisualStyleBackColor = false;
            this.btnAtiv1.Click += new System.EventHandler(this.btnAtiv1_Click);
            // 
            // gbAtiv3
            // 
            this.gbAtiv3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbAtiv3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gbAtiv3.BackgroundImage")));
            this.gbAtiv3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gbAtiv3.Controls.Add(this.label5);
            this.gbAtiv3.Controls.Add(this.label6);
            this.gbAtiv3.Controls.Add(this.btnAtiv3);
            this.gbAtiv3.Location = new System.Drawing.Point(12, 198);
            this.gbAtiv3.Name = "gbAtiv3";
            this.gbAtiv3.Size = new System.Drawing.Size(249, 101);
            this.gbAtiv3.TabIndex = 1;
            this.gbAtiv3.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(88, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 39);
            this.label5.TabIndex = 6;
            this.label5.Text = "Programa que lê uma \r\nsequência de caracteres e \r\ndiz se é palíndromo ou não.\r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(88, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Exercício 3";
            // 
            // btnAtiv3
            // 
            this.btnAtiv3.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnAtiv3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtiv3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAtiv3.Location = new System.Drawing.Point(6, 19);
            this.btnAtiv3.Name = "btnAtiv3";
            this.btnAtiv3.Size = new System.Drawing.Size(76, 76);
            this.btnAtiv3.TabIndex = 1;
            this.btnAtiv3.Text = "Ir";
            this.btnAtiv3.UseVisualStyleBackColor = false;
            this.btnAtiv3.Click += new System.EventHandler(this.btnAtiv3_Click);
            // 
            // gbAtiv2
            // 
            this.gbAtiv2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbAtiv2.BackColor = System.Drawing.SystemColors.Menu;
            this.gbAtiv2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gbAtiv2.BackgroundImage")));
            this.gbAtiv2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gbAtiv2.Controls.Add(this.label3);
            this.gbAtiv2.Controls.Add(this.label4);
            this.gbAtiv2.Controls.Add(this.btnAtiv2);
            this.gbAtiv2.Location = new System.Drawing.Point(290, 91);
            this.gbAtiv2.Name = "gbAtiv2";
            this.gbAtiv2.Size = new System.Drawing.Size(249, 101);
            this.gbAtiv2.TabIndex = 2;
            this.gbAtiv2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(88, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 39);
            this.label3.TabIndex = 4;
            this.label3.Text = "Programa para gerar o nº H. \r\nO número N será fornecido\r\nem um TextBox.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(88, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Exercício 2";
            // 
            // btnAtiv2
            // 
            this.btnAtiv2.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnAtiv2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtiv2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAtiv2.Location = new System.Drawing.Point(6, 19);
            this.btnAtiv2.Name = "btnAtiv2";
            this.btnAtiv2.Size = new System.Drawing.Size(76, 76);
            this.btnAtiv2.TabIndex = 1;
            this.btnAtiv2.Text = "Ir";
            this.btnAtiv2.UseVisualStyleBackColor = false;
            this.btnAtiv2.Click += new System.EventHandler(this.btnAtiv2_Click);
            // 
            // gbAtiv4
            // 
            this.gbAtiv4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbAtiv4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gbAtiv4.BackgroundImage")));
            this.gbAtiv4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gbAtiv4.Controls.Add(this.label7);
            this.gbAtiv4.Controls.Add(this.label8);
            this.gbAtiv4.Controls.Add(this.btnAtiv4);
            this.gbAtiv4.Location = new System.Drawing.Point(290, 198);
            this.gbAtiv4.Name = "gbAtiv4";
            this.gbAtiv4.Size = new System.Drawing.Size(249, 101);
            this.gbAtiv4.TabIndex = 3;
            this.gbAtiv4.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(88, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 39);
            this.label7.TabIndex = 8;
            this.label7.Text = "Programa que calcula o \r\nsalário bruto dos funcionários \r\nde uma empresa.\r\n";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(88, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Exercício 4";
            // 
            // btnAtiv4
            // 
            this.btnAtiv4.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnAtiv4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtiv4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAtiv4.Location = new System.Drawing.Point(6, 19);
            this.btnAtiv4.Name = "btnAtiv4";
            this.btnAtiv4.Size = new System.Drawing.Size(76, 76);
            this.btnAtiv4.TabIndex = 1;
            this.btnAtiv4.Text = "Ir";
            this.btnAtiv4.UseVisualStyleBackColor = false;
            this.btnAtiv4.Click += new System.EventHandler(this.btnAtiv4_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(52, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(441, 30);
            this.label9.TabIndex = 4;
            this.label9.Text = "Linguagem de Programação II - Atividade 6";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Menu;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(551, 310);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.gbAtiv4);
            this.Controls.Add(this.gbAtiv2);
            this.Controls.Add(this.gbAtiv3);
            this.Controls.Add(this.gbAtiv1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Atividade 6";
            this.gbAtiv1.ResumeLayout(false);
            this.gbAtiv1.PerformLayout();
            this.gbAtiv3.ResumeLayout(false);
            this.gbAtiv3.PerformLayout();
            this.gbAtiv2.ResumeLayout(false);
            this.gbAtiv2.PerformLayout();
            this.gbAtiv4.ResumeLayout(false);
            this.gbAtiv4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbAtiv1;
        private System.Windows.Forms.Button btnAtiv1;
        private System.Windows.Forms.GroupBox gbAtiv3;
        private System.Windows.Forms.Button btnAtiv3;
        private System.Windows.Forms.GroupBox gbAtiv2;
        private System.Windows.Forms.Button btnAtiv2;
        private System.Windows.Forms.GroupBox gbAtiv4;
        private System.Windows.Forms.Button btnAtiv4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

