﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (txtNum.Text == "")
            {
                MessageBox.Show("Campo vazio!");
            }
            else {
                int N = Convert.ToInt32(txtNum.Text);
                double H = 0;
                for (int i = 1; i <= N ; i++)
                {
                    H += (1.0 / i);
                }
                MessageBox.Show("Número H = " + H.ToString("F"));
            }
        }

        private void txtNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Se a tecla digitada não for número e nem backspace
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 08)
            { 
                //Atribui True no Handled para cancelar o evento
                e.Handled = true;
            }
        }
    }
}
