﻿namespace Atividade6
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExercicio1));
            this.rctxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnEspacos = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnPares = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rctxtTexto
            // 
            this.rctxtTexto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rctxtTexto.Location = new System.Drawing.Point(114, 12);
            this.rctxtTexto.Name = "rctxtTexto";
            this.rctxtTexto.Size = new System.Drawing.Size(325, 181);
            this.rctxtTexto.TabIndex = 0;
            this.rctxtTexto.Text = "";
            // 
            // btnEspacos
            // 
            this.btnEspacos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnEspacos.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnEspacos.Location = new System.Drawing.Point(114, 220);
            this.btnEspacos.Name = "btnEspacos";
            this.btnEspacos.Size = new System.Drawing.Size(103, 51);
            this.btnEspacos.TabIndex = 1;
            this.btnEspacos.Text = "Nº de espaços em branco";
            this.btnEspacos.UseVisualStyleBackColor = false;
            this.btnEspacos.Click += new System.EventHandler(this.btnEspacos_Click);
            // 
            // btnR
            // 
            this.btnR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnR.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnR.Location = new System.Drawing.Point(225, 220);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(103, 51);
            this.btnR.TabIndex = 2;
            this.btnR.Text = "Nº de vezes em que aparece \"R\"";
            this.btnR.UseVisualStyleBackColor = false;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // btnPares
            // 
            this.btnPares.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPares.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnPares.Location = new System.Drawing.Point(336, 220);
            this.btnPares.Name = "btnPares";
            this.btnPares.Size = new System.Drawing.Size(103, 51);
            this.btnPares.TabIndex = 3;
            this.btnPares.Text = "Nº de vezes em que ocorre par de letras";
            this.btnPares.UseVisualStyleBackColor = false;
            this.btnPares.Click += new System.EventHandler(this.btnPares_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(551, 310);
            this.Controls.Add(this.btnPares);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnEspacos);
            this.Controls.Add(this.rctxtTexto);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmExercicio1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exercício 1";
            this.Load += new System.EventHandler(this.frmExercicio1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctxtTexto;
        private System.Windows.Forms.Button btnEspacos;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnPares;
    }
}