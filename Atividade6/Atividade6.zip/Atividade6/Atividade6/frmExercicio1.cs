﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();

        }

        private void btnEspacos_Click(object sender, EventArgs e)
        {
            if (rctxtTexto.Text.Length > 100)
            {
                MessageBox.Show("Limite máximo de 100 caracteres excedido. ");
            }
            else
            {
                int contador = 0;
                for (var x = 0; x < rctxtTexto.Text.Length; x++)
                {
                    if (Char.IsWhiteSpace(rctxtTexto.Text[x]))
                        contador += 1;
                }
                MessageBox.Show("Número de espaços em branco na frase: " + contador);
            }
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            if (rctxtTexto.Text.Length > 100)
            {
                MessageBox.Show("Limite máximo de 100 caracteres excedido. ");
            }
            else
            {
                rctxtTexto.Text = rctxtTexto.Text.ToUpper();
                var cont = rctxtTexto.Text.Split('R');
                MessageBox.Show("Número de vezes em que ocorre o caracter 'R' na frase: " + Convert.ToString(cont.Length - 1));
            }
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int x = 0;
            int numero = 0; 
            string letra = "";
            while (rctxtTexto.Text.Length - 1 >= x)
            {
                if (rctxtTexto.Text.Substring(x,1) != "" && rctxtTexto.Text.Substring(x,1)==letra)
                { 
                    numero+=1;
                }
                letra = rctxtTexto.Text.Substring(x, 1);
                x++;
            }
            MessageBox.Show("Número de vezes em que ocorre par de letras: " + numero.ToString());
        }

        private void frmExercicio1_Load(object sender, EventArgs e)
        {

        }
    }
}
