﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permitindo inserir apenas letras, espaço e teclar backspace
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != 08 && e.KeyChar != 32)
            {
                e.Handled = true;
            }
        }

        private void txtInscricao_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permitindo inserir apenas digito,backspace
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 08)
            {
                e.Handled = true;
            }
        }

        private void txtProducao_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 08)
            {
                e.Handled = true;
            }
        }

        private void txtCargo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != 08 && e.KeyChar != 32)
            {
                e.Handled = true;
            }
        }

        private void txtSalario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 08 && e.KeyChar != 44)
            {
                e.Handled = true;
            }
        }

        private void txtGratificacao_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 08 && e.KeyChar != 44)
            {
                e.Handled = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(txtNome.Text=="" || txtInscricao.Text=="" || txtProducao.Text=="" || txtCargo.Text=="" || txtSalario.Text=="" || txtGratificacao.Text == "")
            {
                MessageBox.Show("Há espaços em branco. Preencha os campos corretamente!");
            }
            else
            {
                int producao = Convert.ToInt32(txtProducao.Text);
                int B = 0, C = 0, D = 0;
                double A = Convert.ToDouble(txtSalario.Text), totGratific = Convert.ToDouble(txtGratificacao.Text);
                if (producao >= 100)
                    B = 1;
                if (producao >= 120)
                    C = 1;
                if (producao >= 150)
                    D = 1;

                double salBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + totGratific;

                if (salBruto > 7000)
                {
                    if (D == 1 && totGratific > 0)
                    {
                        MessageBox.Show("Salário bruto = " + salBruto.ToString("C2"));
                    }
                    else
                    {
                        MessageBox.Show("Salário bruto = R$ 7.000,00");
                    }
                }
                else
                {
                    MessageBox.Show("Salário bruto = " + salBruto.ToString("C2"));
                }
            }
        }
    }
}
