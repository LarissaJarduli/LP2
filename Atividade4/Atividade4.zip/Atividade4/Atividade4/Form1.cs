﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((txtNome.Text == String.Empty) || (txtSalBruto.Text == String.Empty) || (txtFilhos.Text == String.Empty) || (rbFeminino.Checked == false && rbMasculino.Checked == false))
                MessageBox.Show("Há campos vazios, preencha o formulário corretamente!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            else
            {
                double salBruto;
                int qtdFilho;

                if ((double.TryParse(txtSalBruto.Text, out salBruto)) && (int.TryParse(txtFilhos.Text, out qtdFilho)))
                {
                    //Inserindo dados do funcionário no label
                    if (cbCasado.Checked == true)
                    {
                        if (rbFeminino.Checked == true)
                            lblDados.Text = "Os descontos do salário da Srª " + txtNome.Text + "\nQue é Casada\nE que tem " + qtdFilho + " filho(s), são:";
                        else if (rbMasculino.Checked == true)
                            lblDados.Text = "Os descontos do salário da Srº " + txtNome.Text + "\nQue é Casado\nE que tem " + qtdFilho + " filho(s), são:";
                    }
                    else 
                    {
                        if (rbFeminino.Checked == true)
                            lblDados.Text = "Os descontos do salário da Srª " + txtNome.Text + "\nQue é Solteira\nE que tem " + qtdFilho + " filho(s), são:";
                        else if (rbMasculino.Checked == true)
                            lblDados.Text = "Os descontos do salário da Srº " + txtNome.Text + "\nQue é Solteiro\nE que tem " + qtdFilho + " filho(s), são:";
                    }

                    //Calculando os descontos
                    double aliqINSS = 0, descINSS, aliqIRPF = 0, descIRPF, salFamilia = 0, salLiq;

                    //para INSS
                    if (salBruto <= 800.57)
                        aliqINSS = 7.65;
                    else if(salBruto > 800.57 && salBruto <= 1050)
                        aliqINSS = 8.65;
                    else if (salBruto > 1050 && salBruto <= 1400.77)
                        aliqINSS = 9.00;
                    else if (salBruto > 1400.77 && salBruto <= 2801.56)
                        aliqINSS = 11.00;
                    else if (salBruto > 2801.56)
                        aliqINSS = 30.817;

                    descINSS = aliqINSS * 10;

                    //para IRPF
                    if (salBruto <= 1257.12)
                        aliqIRPF = 0;
                    else if (salBruto > 1257.12 && salBruto <= 2512.08)
                        aliqIRPF = 15.00;
                    else if (salBruto > 2512.08)
                        aliqINSS = 27.50;

                    descIRPF = aliqIRPF * 10;

                    //para Salário Família
                    if (salBruto <= 435.52)
                        salFamilia = qtdFilho * 22.33;
                    else if (salBruto > 435.52 && salBruto <= 654.61)
                        salFamilia = qtdFilho * 15.74;
                    else if (salBruto > 654.61)
                        salFamilia = 0;

                    //Salário Líquido
                    salLiq = salBruto - descINSS - descIRPF + salFamilia;

                    txtAliqINSS.Text = aliqINSS + "%";
                    txtAliqIRPF.Text = aliqIRPF + "%";
                    txtDescINSS.Text = "R$ " + descINSS;
                    txtDescIRPF.Text = "R$ " + descIRPF;
                    txtSalFamilia.Text = "R$ " + salFamilia;
                    txtSalLiq.Text = "R$ " + salLiq;

                }
            }
        }
    }
}
