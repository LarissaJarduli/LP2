﻿namespace Atividade4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.gbSexo = new System.Windows.Forms.GroupBox();
            this.rbMasculino = new System.Windows.Forms.RadioButton();
            this.rbFeminino = new System.Windows.Forms.RadioButton();
            this.cbCasado = new System.Windows.Forms.CheckBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lblDados = new System.Windows.Forms.Label();
            this.gbDados = new System.Windows.Forms.GroupBox();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblDescIRFF = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblAliqIRFF = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.txtSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtFilhos = new System.Windows.Forms.MaskedTextBox();
            this.txtNome = new System.Windows.Forms.MaskedTextBox();
            this.txtAliqINSS = new System.Windows.Forms.MaskedTextBox();
            this.txtAliqIRPF = new System.Windows.Forms.MaskedTextBox();
            this.txtSalFamilia = new System.Windows.Forms.MaskedTextBox();
            this.txtDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.txtDescIRPF = new System.Windows.Forms.MaskedTextBox();
            this.txtSalLiq = new System.Windows.Forms.MaskedTextBox();
            this.gbSexo.SuspendLayout();
            this.gbDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 23);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(105, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do funcionário";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(12, 82);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(66, 13);
            this.lblSalBruto.TabIndex = 2;
            this.lblSalBruto.Text = "Salário bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(143, 82);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(61, 13);
            this.lblFilhos.TabIndex = 4;
            this.lblFilhos.Text = "Nº de filhos";
            // 
            // gbSexo
            // 
            this.gbSexo.Controls.Add(this.rbMasculino);
            this.gbSexo.Controls.Add(this.rbFeminino);
            this.gbSexo.Location = new System.Drawing.Point(254, 23);
            this.gbSexo.Name = "gbSexo";
            this.gbSexo.Size = new System.Drawing.Size(94, 72);
            this.gbSexo.TabIndex = 6;
            this.gbSexo.TabStop = false;
            this.gbSexo.Text = "Sexo";
            // 
            // rbMasculino
            // 
            this.rbMasculino.AutoSize = true;
            this.rbMasculino.Location = new System.Drawing.Point(6, 42);
            this.rbMasculino.Name = "rbMasculino";
            this.rbMasculino.Size = new System.Drawing.Size(73, 17);
            this.rbMasculino.TabIndex = 1;
            this.rbMasculino.TabStop = true;
            this.rbMasculino.Text = "Masculino";
            this.rbMasculino.UseVisualStyleBackColor = true;
            // 
            // rbFeminino
            // 
            this.rbFeminino.AutoSize = true;
            this.rbFeminino.Location = new System.Drawing.Point(6, 19);
            this.rbFeminino.Name = "rbFeminino";
            this.rbFeminino.Size = new System.Drawing.Size(67, 17);
            this.rbFeminino.TabIndex = 0;
            this.rbFeminino.TabStop = true;
            this.rbFeminino.Text = "Feminino";
            this.rbFeminino.UseVisualStyleBackColor = true;
            // 
            // cbCasado
            // 
            this.cbCasado.AutoSize = true;
            this.cbCasado.Location = new System.Drawing.Point(260, 101);
            this.cbCasado.Name = "cbCasado";
            this.cbCasado.Size = new System.Drawing.Size(74, 17);
            this.cbCasado.TabIndex = 7;
            this.cbCasado.Text = "Casado(a)";
            this.cbCasado.UseVisualStyleBackColor = true;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(120, 139);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(124, 39);
            this.btnVerificar.TabIndex = 8;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(5, 16);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(38, 13);
            this.lblDados.TabIndex = 9;
            this.lblDados.Text = "Dados";
            // 
            // gbDados
            // 
            this.gbDados.Controls.Add(this.txtSalLiq);
            this.gbDados.Controls.Add(this.txtDescIRPF);
            this.gbDados.Controls.Add(this.txtDescINSS);
            this.gbDados.Controls.Add(this.txtSalFamilia);
            this.gbDados.Controls.Add(this.txtAliqIRPF);
            this.gbDados.Controls.Add(this.txtAliqINSS);
            this.gbDados.Controls.Add(this.lblSalLiq);
            this.gbDados.Controls.Add(this.lblDescIRFF);
            this.gbDados.Controls.Add(this.lblDescINSS);
            this.gbDados.Controls.Add(this.lblSalFamilia);
            this.gbDados.Controls.Add(this.lblAliqIRFF);
            this.gbDados.Controls.Add(this.lblAliqINSS);
            this.gbDados.Controls.Add(this.lblDados);
            this.gbDados.Location = new System.Drawing.Point(12, 197);
            this.gbDados.Name = "gbDados";
            this.gbDados.Size = new System.Drawing.Size(343, 177);
            this.gbDados.TabIndex = 10;
            this.gbDados.TabStop = false;
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(236, 127);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(78, 13);
            this.lblSalLiq.TabIndex = 20;
            this.lblSalLiq.Text = "Salário Líquido";
            // 
            // lblDescIRFF
            // 
            this.lblDescIRFF.AutoSize = true;
            this.lblDescIRFF.Location = new System.Drawing.Point(122, 127);
            this.lblDescIRFF.Name = "lblDescIRFF";
            this.lblDescIRFF.Size = new System.Drawing.Size(80, 13);
            this.lblDescIRFF.TabIndex = 18;
            this.lblDescIRFF.Text = "Desconto IRPF";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(5, 127);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescINSS.TabIndex = 16;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(237, 83);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalFamilia.TabIndex = 14;
            this.lblSalFamilia.Text = "Salário Família";
            // 
            // lblAliqIRFF
            // 
            this.lblAliqIRFF.AutoSize = true;
            this.lblAliqIRFF.Location = new System.Drawing.Point(122, 83);
            this.lblAliqIRFF.Name = "lblAliqIRFF";
            this.lblAliqIRFF.Size = new System.Drawing.Size(74, 13);
            this.lblAliqIRFF.TabIndex = 12;
            this.lblAliqIRFF.Text = "Alíquota IRPF";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(5, 83);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(75, 13);
            this.lblAliqINSS.TabIndex = 10;
            this.lblAliqINSS.Text = "Alíquota INSS";
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.Location = new System.Drawing.Point(15, 98);
            this.txtSalBruto.Mask = "999999.99";
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalBruto.TabIndex = 22;
            // 
            // txtFilhos
            // 
            this.txtFilhos.Location = new System.Drawing.Point(146, 98);
            this.txtFilhos.Mask = "99";
            this.txtFilhos.Name = "txtFilhos";
            this.txtFilhos.Size = new System.Drawing.Size(58, 20);
            this.txtFilhos.TabIndex = 23;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(15, 39);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(189, 20);
            this.txtNome.TabIndex = 24;
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(8, 99);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(96, 20);
            this.txtAliqINSS.TabIndex = 22;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Location = new System.Drawing.Point(125, 99);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(96, 20);
            this.txtAliqIRPF.TabIndex = 23;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(239, 99);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(96, 20);
            this.txtSalFamilia.TabIndex = 24;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(8, 143);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(96, 20);
            this.txtDescINSS.TabIndex = 25;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(125, 143);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(96, 20);
            this.txtDescIRPF.TabIndex = 26;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(239, 143);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(96, 20);
            this.txtSalLiq.TabIndex = 27;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 386);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtFilhos);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.gbDados);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.cbCasado);
            this.Controls.Add(this.gbSexo);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Atividade 4";
            this.gbSexo.ResumeLayout(false);
            this.gbSexo.PerformLayout();
            this.gbDados.ResumeLayout(false);
            this.gbDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.GroupBox gbSexo;
        private System.Windows.Forms.RadioButton rbMasculino;
        private System.Windows.Forms.RadioButton rbFeminino;
        private System.Windows.Forms.CheckBox cbCasado;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.GroupBox gbDados;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblDescIRFF;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblAliqIRFF;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.MaskedTextBox txtSalBruto;
        private System.Windows.Forms.MaskedTextBox txtFilhos;
        private System.Windows.Forms.MaskedTextBox txtSalLiq;
        private System.Windows.Forms.MaskedTextBox txtDescIRPF;
        private System.Windows.Forms.MaskedTextBox txtDescINSS;
        private System.Windows.Forms.MaskedTextBox txtSalFamilia;
        private System.Windows.Forms.MaskedTextBox txtAliqIRPF;
        private System.Windows.Forms.MaskedTextBox txtAliqINSS;
        private System.Windows.Forms.MaskedTextBox txtNome;
    }
}

