﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Atividade7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";
            for (x = 0; x < 20; x++) {
                valor = Interaction.InputBox("Digite o dado" + (x + 1), "Entrade de dados");
                if (int.TryParse(valor, out vetor[x])) {
                    //auxiliar = auxiliar + "\n" + vetor[x].ToString(); 
                    auxiliar = vetor[x].ToString() + "\n" + auxiliar;
                }
                else
                {
                    MessageBox.Show("Número inválido!");
                    x--;
                }
            }
            MessageBox.Show(auxiliar);
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[] qtd = new double[10];
            double[] preco = new double[10];
            double total = 0;

            for (int i = 0; i < 10; i++)
            {
                string valorQtd = Interaction.InputBox("Digite a quantidade: " + (i + 1), "Entrada de dados");
                string valorPreco = Interaction.InputBox("Digite o preço: " + (i + 1), "Entrada de dados");

                if (double.TryParse(valorQtd,out qtd[i]) && double.TryParse(valorPreco,out preco[i]))
                {
                    total = qtd[i] * preco[i];

                }
                else
                {
                    MessageBox.Show("Números inválidos!");
                    i--;
                }

                MessageBox.Show(total.ToString("C2"));
            }
            
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";
            for (x = 0; x < 20; x++) {
                valor = Interaction.InputBox("Digite o dado da posição: " + (x + 1), "Digite os dados");
                if (!int.TryParse(valor, out vetor[x])) {
                    MessageBox.Show("Número inválido!");
                    x--;
                }
            }
            Array.Reverse(vetor);
            for (x = 0; x < 20; x++) {
                auxiliar += vetor[x] + "\n";   
            }
            MessageBox.Show(auxiliar);
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "José", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
                Total += Alunos[I].Length;
            MessageBox.Show(Total.ToString());
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            List<string> lista = new List<string>(new string[] {"Ana","André","Débora","Fátima","João","Janete","Otávio","Marcelo","Pedro","Thais"});
            lista.Remove("Otávio");

            foreach(string elemento in lista)
                MessageBox.Show(elemento.ToString());
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            double[,] tabela = new double[20, 3];
            string valor = "";
            for (int x = 0; x < 20; x++)
            {
                for (int i = 0; i < 3; i++)
                {
                    valor = Interaction.InputBox("Digite a nota " + (i + 1) + " do aluno " + (x + 1), "Digite os dados");
                    if (!double.TryParse(valor, out tabela[x, i]))
                    {
                        MessageBox.Show("Número inválido!");
                        i--;
                    }
                }  
            }

            double media = 0;
            for (int x = 0; x < 20; x++)
            {
                media = (tabela[x, 0] + tabela[x, 1] + tabela[x, 2]) / 3;
                MessageBox.Show("Aluno " + (x + 1) + ": Média: " + media.ToString("F"));
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            lbExercicio7.Items.Clear();
            int n;
            string valor = "";
            

            valor = Interaction.InputBox("Digite seu ultimo numero do RA", "Digite os dados");
            if (!int.TryParse(valor, out n))
                MessageBox.Show("Número inválido!");
            if (n > 9 || n < 0)
                MessageBox.Show("Número inválido! Digite um número entre zero e nove.");
            else if (n == 0)
                n = 10;
            else
            {
                string[] nomes = new string[n];
                int[] tamanhoNome = new int[n];
                string semEspaco;
                
                for (int i = 0; i < n; i++)
                {
                    nomes[i] = Interaction.InputBox("Digite o nome " + (i + 1), "Digite os dados");
                    semEspaco = nomes[i].Replace(" ","");
                    tamanhoNome[i] = semEspaco.Length;
                }

                for (int x = 0; x < n; x++)
                {
                    lbExercicio7.Items.Add("O nome " + nomes[x] + " tem " + tamanhoNome[x] + " caracteres");
                }
            }

        }
    }
}
