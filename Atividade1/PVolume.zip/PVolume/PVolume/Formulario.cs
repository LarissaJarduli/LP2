﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Formulario : Form
    {
        public Formulario()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((txtRaio.Text == String.Empty) || (txtAltura.Text == String.Empty))
                MessageBox.Show("Há campos vazios, preencha os campos corretamente!","Erro",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            else
            {
                double raio, altura;
                if ((double.TryParse(txtRaio.Text, out raio)) && (double.TryParse(txtAltura.Text, out altura)))
                {
                    double volume = Math.PI * Math.Pow(raio, 2) * altura;
                    MessageBox.Show("Volume do cilindro: " + volume.ToString("N2"),"Resultado",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
            
        }

        private void txtRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Validação do textbox para que aceite somente números e uma vírgula apenas
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente números e vírgula","Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente uma vírgula","Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void txtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Validação do textbox para que aceite somente números e uma vírgula apenas
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente números e vírgula","Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente uma vírgula","Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Clear();
            txtAltura.Clear();
        }
    }
}
