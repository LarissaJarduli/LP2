﻿namespace PVolume
{
    partial class Formulario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Formulario));
            this.gbVolCilindro = new System.Windows.Forms.GroupBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.lblAltura = new System.Windows.Forms.Label();
            this.txtRaio = new System.Windows.Forms.TextBox();
            this.lblRaio = new System.Windows.Forms.Label();
            this.pbCilindro = new System.Windows.Forms.PictureBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.gbVolCilindro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCilindro)).BeginInit();
            this.SuspendLayout();
            // 
            // gbVolCilindro
            // 
            this.gbVolCilindro.Controls.Add(this.btnLimpar);
            this.gbVolCilindro.Controls.Add(this.btnCalcular);
            this.gbVolCilindro.Controls.Add(this.txtAltura);
            this.gbVolCilindro.Controls.Add(this.lblAltura);
            this.gbVolCilindro.Controls.Add(this.txtRaio);
            this.gbVolCilindro.Controls.Add(this.lblRaio);
            this.gbVolCilindro.Controls.Add(this.pbCilindro);
            this.gbVolCilindro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbVolCilindro.Location = new System.Drawing.Point(8, 11);
            this.gbVolCilindro.Name = "gbVolCilindro";
            this.gbVolCilindro.Size = new System.Drawing.Size(360, 209);
            this.gbVolCilindro.TabIndex = 0;
            this.gbVolCilindro.TabStop = false;
            this.gbVolCilindro.Text = "Cálculo de Volume do Cilindro";
            // 
            // btnCalcular
            // 
            this.btnCalcular.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnCalcular.Location = new System.Drawing.Point(61, 117);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(79, 38);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtAltura
            // 
            this.txtAltura.Location = new System.Drawing.Point(117, 64);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(79, 24);
            this.txtAltura.TabIndex = 4;
            this.txtAltura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAltura_KeyPress);
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltura.Location = new System.Drawing.Point(114, 45);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(56, 15);
            this.lblAltura.TabIndex = 3;
            this.lblAltura.Text = "Altura (h)";
            // 
            // txtRaio
            // 
            this.txtRaio.Location = new System.Drawing.Point(9, 64);
            this.txtRaio.Name = "txtRaio";
            this.txtRaio.Size = new System.Drawing.Size(79, 24);
            this.txtRaio.TabIndex = 2;
            this.txtRaio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRaio_KeyPress);
            // 
            // lblRaio
            // 
            this.lblRaio.AutoSize = true;
            this.lblRaio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaio.Location = new System.Drawing.Point(6, 45);
            this.lblRaio.Name = "lblRaio";
            this.lblRaio.Size = new System.Drawing.Size(48, 15);
            this.lblRaio.TabIndex = 1;
            this.lblRaio.Text = "Raio (r)";
            // 
            // pbCilindro
            // 
            this.pbCilindro.Image = ((System.Drawing.Image)(resources.GetObject("pbCilindro.Image")));
            this.pbCilindro.Location = new System.Drawing.Point(196, 23);
            this.pbCilindro.Name = "pbCilindro";
            this.pbCilindro.Size = new System.Drawing.Size(158, 180);
            this.pbCilindro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCilindro.TabIndex = 0;
            this.pbCilindro.TabStop = false;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(61, 161);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(79, 23);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Formulario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 232);
            this.Controls.Add(this.gbVolCilindro);
            this.Name = "Formulario";
            this.Text = "Linguagem de Programação II - Atividade 3";
            this.gbVolCilindro.ResumeLayout(false);
            this.gbVolCilindro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCilindro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbVolCilindro;
        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.TextBox txtRaio;
        private System.Windows.Forms.Label lblRaio;
        private System.Windows.Forms.PictureBox pbCilindro;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
    }
}

