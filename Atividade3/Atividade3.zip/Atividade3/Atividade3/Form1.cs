﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((txtA.Text == String.Empty) || (txtB.Text == String.Empty) || (txtC.Text == String.Empty))
                MessageBox.Show("Há campos vazios, preencha os campos corretamente!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            else
            {
                double a, b, c;
                if ((double.TryParse(txtA.Text, out a)) && (double.TryParse(txtB.Text, out b)) && (double.TryParse(txtC.Text, out c)))
                {
                    if ((a < (b + c)) && (b < (a + c)) && (c < (a + b)))
                    {
                        if (a == b && b == c)
                            MessageBox.Show("Triângulo equilatero");
                        else if (a == b || b == c || a == c)
                            MessageBox.Show("Triângulo isósceles");
                        else 
                            MessageBox.Show("Triângulo qualquer");
                    }
                    else
                        MessageBox.Show("Não é um triângulo");
                }
            }
        }

        private void txtA_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Validação do textbox para que aceite somente números e uma vírgula apenas
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente números e vírgula", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente uma vírgula", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void txtB_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Validação do textbox para que aceite somente números e uma vírgula apenas
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente números e vírgula", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente uma vírgula", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void txtC_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Validação do textbox para que aceite somente números e uma vírgula apenas
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente números e vírgula", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
                MessageBox.Show("Este campo aceita somente uma vírgula", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
