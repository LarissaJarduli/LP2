﻿namespace Atividade3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbVerificarValores = new System.Windows.Forms.GroupBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtC = new System.Windows.Forms.TextBox();
            this.lblC = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.lblB = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.lblA = new System.Windows.Forms.Label();
            this.gbVerificarValores.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbVerificarValores
            // 
            this.gbVerificarValores.Controls.Add(this.btnVerificar);
            this.gbVerificarValores.Controls.Add(this.txtC);
            this.gbVerificarValores.Controls.Add(this.lblC);
            this.gbVerificarValores.Controls.Add(this.txtB);
            this.gbVerificarValores.Controls.Add(this.lblB);
            this.gbVerificarValores.Controls.Add(this.txtA);
            this.gbVerificarValores.Controls.Add(this.lblA);
            this.gbVerificarValores.Location = new System.Drawing.Point(12, 12);
            this.gbVerificarValores.Name = "gbVerificarValores";
            this.gbVerificarValores.Size = new System.Drawing.Size(251, 210);
            this.gbVerificarValores.TabIndex = 0;
            this.gbVerificarValores.TabStop = false;
            this.gbVerificarValores.Text = "Insira os valores";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(136, 82);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(71, 38);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(34, 131);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(48, 20);
            this.txtC.TabIndex = 5;
            this.txtC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtC_KeyPress);
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(11, 134);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(17, 13);
            this.lblC.TabIndex = 4;
            this.lblC.Text = "C:";
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(34, 92);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(48, 20);
            this.txtB.TabIndex = 3;
            this.txtB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtB_KeyPress);
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(11, 95);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(17, 13);
            this.lblB.TabIndex = 2;
            this.lblB.Text = "B:";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(34, 53);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(48, 20);
            this.txtA.TabIndex = 1;
            this.txtA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtA_KeyPress);
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(11, 56);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(17, 13);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "A:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 234);
            this.Controls.Add(this.gbVerificarValores);
            this.Name = "Form1";
            this.Text = "Atividade 3";
            this.gbVerificarValores.ResumeLayout(false);
            this.gbVerificarValores.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbVerificarValores;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label lblA;
    }
}

