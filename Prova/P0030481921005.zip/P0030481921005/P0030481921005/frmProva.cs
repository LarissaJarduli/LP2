﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace P0030481921005
{
    public partial class frmProva : Form
    {
        public frmProva()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lbLista.Items.Clear();
            int n;
            string valor = "";


            valor = Interaction.InputBox("Digite seu ultimo numero do RA", "Digite os dados");
            if (!int.TryParse(valor, out n))
                MessageBox.Show("Número inválido!");
            if (n > 9 || n < 0)
                MessageBox.Show("Número inválido! Digite um número entre zero e nove.");
            else if (n == 0)
                n = 10;
            else
            {
                double[,] tabVendas = new double[n, 4];
                string valorTabela = "";

                for (int i = 0; i < n; i++)
                {
                    for (int x = 0; x < 4; x++)
                    {
                        valorTabela = Interaction.InputBox("Digite o valor das vendas do mês " + (i + 1) + ", semana " + (x + 1), "Digite os dados");
                        if (!double.TryParse(valorTabela, out tabVendas[i,x]))
                        {
                            MessageBox.Show("Número inválido!");
                            x--;
                        }
                    }
                }
                double totalSemana, totalMes, totalGeral, acumulador = 0, acumuladorMes = 0;

                for (int i = 0; i < n; i++)
                {
                    for (int x = 0; x < 4; x++)
                    {
                        totalSemana = tabVendas[i, x];
                        lbLista.Items.Add("Total do mês " + (i + 1) + " Semana " + (x + 1) + ": " + totalSemana.ToString("C2"));
                        acumulador += totalSemana;
                    }
                    totalMes = acumulador;
                    lbLista.Items.Add(">> Total Mês: " + totalMes.ToString("C2"));
                    lbLista.Items.Add("-----------------------");
                    acumulador = 0;
                    acumuladorMes += totalMes;
                }
                totalGeral = acumuladorMes;
                lbLista.Items.Add("Total Geral: " + totalGeral.ToString("C2"));
            }

        }
    }
}
