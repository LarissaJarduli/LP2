﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if((txtPeso.Text == String.Empty) || (txtAltura.Text == String.Empty) || (rbFeminino.Checked == false)&&(rbMasculino.Checked == false))
                MessageBox.Show("Há campos vazios, preencha e selecione os campos corretamente!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            else
            {
                double peso, altura;
                if ((double.TryParse(txtPeso.Text, out peso)) && (double.TryParse(txtAltura.Text, out altura)))
                {
                    if (rbFeminino.Checked == true)
                    {
                        double pesoIdeal = (62.1 * altura) - 44.7;
                        MessageBox.Show("Peso atual: " + peso.ToString("N2") + "\nPeso Ideal: " + pesoIdeal.ToString("N2"));
                        if (pesoIdeal < peso)
                            MessageBox.Show("Regime obrigatório já!");
                        else if (pesoIdeal == peso)
                            MessageBox.Show("Você está com o peso ideal!");
                        else if (pesoIdeal > peso)
                            MessageBox.Show("Coma bastante massas e doces!");
                    }
                    else if (rbMasculino.Checked == true)
                    {
                        double pesoIdeal = (72.7 * altura) - 58;
                        MessageBox.Show("Peso atual: " + peso.ToString("N2") + "\nPeso Ideal: " + pesoIdeal.ToString("N2"));
                        if (pesoIdeal < peso)
                            MessageBox.Show("Regime obrigatório já!");
                        else if (pesoIdeal == peso)
                            MessageBox.Show("Você está com o peso ideal!");
                        else if (pesoIdeal > peso)
                            MessageBox.Show("Coma bastante massas e doces!");
                    }

                }
            }
        }
    }
}
